package com.prajeev.secureweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurewebApplicationTests {

	@Test
	void contextLoads() {
	}

}
