package com.prajeev.secureweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurewebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurewebApplication.class, args);
	}

}
